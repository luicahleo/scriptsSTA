#!/bin/sh
#
# Para se coja el hostname por DHCP
# Ubicarlo en: /etc/dhcp/dhclient-exit-hooks.d
#
# Update hostname from DHCP
#
if [ "$reason" != BOUND ] && [ "$reason" != RENEW ] && [ "$reason" != REBIND ] && [ "$reason" != REBOOT ]; then
    return
    fi

NOMBRE="linux"
if [ -n "$new_host_name" ]; then
    NOMBRE=$new_host_name
elif [ -n "$new_ip_address" ]; then
    NOMBRE=$new_ip_address
fi

hostname $NOMBRE
echo $NOMBRE > /etc/hostname
